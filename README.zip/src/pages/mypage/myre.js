let myre = [{
    id: 0,
    title: "마포 난지천 인조잔디",
    area: "서울시 마포구",
    price: "50,000원",
    img: "https://cdn.latimes.kr/news/photo/202110/38820_52627_2553.jpg"
},

{
    id: 1,
    title: "목동 종합운동장",
    area: "서울시 양천구",
    price: "45,000원",
    img: "https://storage.heypop.kr/assets/2022/10/24110920/t-30.jpg"
},
]

export default myre;