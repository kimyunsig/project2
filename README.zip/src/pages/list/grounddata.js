let grounddata = [{
    id: 0,
    title: "마포 난지천 인조잔디",
    area: "서울시 마포구",
    price: "50,000원",
    img: "https://cdn.latimes.kr/news/photo/202110/38820_52627_2553.jpg"
},

{
    id: 1,
    title: "목동 종합운동장",
    area: "서울시 양천구",
    price: "45,000원",
    img: "https://storage.heypop.kr/assets/2022/10/24110920/t-30.jpg"
},

{
    id: 2,
    title: "파주 JM 풋볼파크",
    area: "파주시 조리읍",
    price: "38,000원",
    img: "https://img.freepik.com/premium-photo/football-stadium-3d-rendering-soccer-stadium-with-crowded-field-arena_3544-1724.jpg"
},

{
    id: 3,
    title: "용인 윙스 농구장",
    area: "용인시 기흥구",
    price: "35,000원",
    img: "https://www.aphroditehills.com/Aphrodite-hills/wp-content/uploads/2022/05/basketball2_2022-1.jpg"
},

{
    id: 4,
    title: "구로누리 배드민턴장",
    area: "서울시 구로구",
    price: "25,000원",
    img: "https://menu.moneys.co.kr/moneyweek/thumb/2021/08/22/06/2021082218018064480_1.jpg"
}
]

export default grounddata;